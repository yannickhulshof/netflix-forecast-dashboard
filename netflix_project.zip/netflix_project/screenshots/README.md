Place your exported dashboard screenshots here, e.g. `dashboard_overview.png`.
Referenced from the main README.
