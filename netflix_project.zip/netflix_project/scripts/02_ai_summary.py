"""
Netflix forecast: AI-samenvatting genereren
----------------------------------------------
Doel: neemt de laatste maanden historie + de eerste maanden voorspelling uit
netflix_forecast.csv, en laat Claude daar een korte, leesbare samenvatting
van schrijven -- dit tekstblokje plak je vervolgens als tekstvak in je
Power BI dashboard.

Benodigd: een eigen Anthropic API-key.
  1. Ga naar https://console.anthropic.com en maak een gratis account.
  2. Maak een API-key aan (Settings -> API Keys).
  3. Zet 'm hieronder in de variabele API_KEY, OF stel 'm in als environment
     variable ANTHROPIC_API_KEY (veiliger, want dan staat je key niet in dit bestand).

Installeer eerst: pip install anthropic pandas
"""

import os
import pandas as pd
import anthropic

# ---------------------------------------------------------
# 1. API-key instellen
# ---------------------------------------------------------
API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")  # of plak hier direct je key als string
if not API_KEY:
    raise ValueError(
        "Geen API-key gevonden. Zet 'm als environment variable ANTHROPIC_API_KEY, "
        "of vul 'm rechtstreeks in bij API_KEY hierboven (minder veilig, niet delen!)."
    )

client = anthropic.Anthropic(api_key=API_KEY)

# ---------------------------------------------------------
# 2. Data inladen en de relevante periode bepalen
# ---------------------------------------------------------
df = pd.read_csv("netflix_forecast.csv")
df["date"] = pd.to_datetime(df["date"])

# Laatste 3 maanden met een echte (bekende) waarde
historie = df[df["actual"].notna()].tail(3)
# Eerste 3 maanden die puur voorspelling zijn (geen 'actual' bekend)
voorspelling = df[df["actual"].isna()].head(3)

# ---------------------------------------------------------
# 3. Prompt opbouwen met de cijfers
# ---------------------------------------------------------
def maandrijen_naar_tekst(rijen, kolom):
    return ", ".join(f"{r['date'].strftime('%B %Y')}: {r[kolom]:.0f}" for _, r in rijen.iterrows())

historie_tekst = maandrijen_naar_tekst(historie, "actual")
voorspelling_tekst = maandrijen_naar_tekst(voorspelling, "forecast")

# Groeipercentage tussen laatste bekende maand en eerste voorspelde maand
laatste_actual = historie["actual"].iloc[-1]
eerste_forecast = voorspelling["forecast"].iloc[0]
groei_pct = (eerste_forecast - laatste_actual) / laatste_actual * 100

prompt = f"""Je bent een data-analist die een kort, zakelijk stukje tekst schrijft voor
een Power BI dashboard over Netflix' content-aanbod.

Data (aantal nieuwe titels per maand):
- Laatste bekende maanden: {historie_tekst}
- Voorspelde eerstvolgende maanden: {voorspelling_tekst}
- Verandering tussen laatste bekende maand en eerste voorspelde maand: {groei_pct:.1f}%

Schrijf een samenvatting van maximaal 3 zinnen, in het Nederlands, in een
professionele/zakelijke toon, geschikt om direct in een dashboard te tonen.
Noem geen onzekerheidsmarges, alleen de kernboodschap. Begin niet met
'Hier is een samenvatting' of iets dergelijks -- schrijf direct de tekst zelf."""

# ---------------------------------------------------------
# 4. Claude aanroepen
# ---------------------------------------------------------
response = client.messages.create(
    model="claude-sonnet-4-6",
    max_tokens=200,
    messages=[{"role": "user", "content": prompt}],
)

samenvatting = response.content[0].text
print("\n=== AI-samenvatting ===\n")
print(samenvatting)

# ---------------------------------------------------------
# 5. Opslaan als tekstbestand (handig om te kopi\u00ebren naar Power BI)
# ---------------------------------------------------------
with open("output/ai_samenvatting.txt", "w", encoding="utf-8") as f:
    f.write(samenvatting)
print("\nOpgeslagen: output/ai_samenvatting.txt")
