# ===========================================================
# STAP 1: Installeer Prophet (eenmalig nodig in Colab)
# ===========================================================
!pip install prophet -q

# ===========================================================
# STAP 2: Upload netflix_titles.csv (het originele Kaggle-bestand)
# ===========================================================
from google.colab import files
uploaded = files.upload()
# Kies "netflix_titles.csv" in het venster dat verschijnt.

# ===========================================================
# STAP 3: Output-map aanmaken
# ===========================================================
import os
os.makedirs("output", exist_ok=True)

# ===========================================================
# STAP 4: Data opschonen + tijdreeks maken
# ===========================================================
import pandas as pd

def ontmantel_excel_export(pad):
    """Herstelt een CSV-bestand dat is 'kapotgemaakt' doordat het ooit in Excel is
    geopend en opnieuw opgeslagen. Excel zet in dat geval de hele oorspronkelijke
    regel tussen aanhalingstekens, verdubbelt interne aanhalingstekens, en voegt
    ';;' toe aan het einde van elke regel."""
    import io
    def ontmantel_regel(line):
        line = line.rstrip("\n").rstrip("\r")
        if line.endswith(";;"):
            line = line[:-2]
        if line.startswith('"') and line.endswith('"'):
            line = line[1:-1]
            line = line.replace('""', '"')
        return line

    with open(pad, encoding="utf-8", errors="replace") as f:
        regels = [ontmantel_regel(l) for l in f]
    return io.StringIO("\n".join(regels))


def is_goed_ingelezen(df):
    """Check niet alleen of de kolomnamen kloppen, maar ook of de data er
    daadwerkelijk goed in staat (anders kan een mislukte parse toch de juiste
    kolomnamen tonen terwijl alle data in de eerste kolom is gepropt)."""
    verwachte_kolommen = {"show_id", "type", "title", "date_added", "listed_in"}
    if not verwachte_kolommen.issubset(set(df.columns)):
        return False
    # Bij een geslaagde parse moet minstens 90% van de rijen een geldige
    # (niet-lege) datum in 'date_added' hebben.
    aandeel_gevuld = df["date_added"].notna().mean()
    return aandeel_gevuld > 0.9


def lees_netflix_csv(pad):
    """Probeert het bestand op de standaard manier te lezen (komma-gescheiden, met
    correcte afhandeling van aanhalingstekens). Valt terug op andere methodes als
    dat nodig blijkt."""
    # Poging 1: standaard komma-gescheiden
    try:
        df = pd.read_csv(pad)
        if is_goed_ingelezen(df):
            return df
    except Exception:
        pass

    # Poging 2: puntkomma-gescheiden (Excel NL-export)
    try:
        df = pd.read_csv(pad, sep=";")
        if is_goed_ingelezen(df):
            return df
    except Exception:
        pass

    # Poging 3: het bestand is dubbel "ingepakt" door Excel (hele regel als
    # tekst tussen quotes, met ';;' aan het einde) -> eerst ontmantelen
    try:
        hersteld = ontmantel_excel_export(pad)
        df = pd.read_csv(hersteld)
        if is_goed_ingelezen(df):
            return df
    except Exception:
        pass

    raise ValueError(
        "Het CSV-bestand kon niet correct worden ingelezen.\n"
        "Check of je echt het originele 'netflix_titles.csv' van Kaggle hebt geupload, "
        "en niet een versie die tussendoor in Excel is geopend en opnieuw is opgeslagen "
        "(dat verandert soms stilletjes het scheidingsteken of de aanhalingstekens)."
    )

df = lees_netflix_csv("netflix_titles.csv")
print(f"Ingeladen: {len(df)} rijen")
print(f"Gevonden kolommen: {list(df.columns)}")

df["date_added"] = pd.to_datetime(df["date_added"], errors="coerce")
df["country"] = df["country"].fillna("Unknown")
df["director"] = df["director"].fillna("Unknown")
df["cast"] = df["cast"].fillna("Unknown")
df["rating"] = df["rating"].fillna("Not Rated")
df["listed_in"] = df["listed_in"].fillna("Unknown")
df["main_country"] = df["country"].apply(lambda x: x.split(",")[0].strip())
df["main_genre"] = df["listed_in"].apply(lambda x: x.split(",")[0].strip())
df["year_added"] = df["date_added"].dt.year
df["month_added"] = df["date_added"].dt.month
df["year_month"] = df["date_added"].dt.to_period("M").astype(str)

df.to_csv("output/netflix_titles_clean.csv", index=False)
print(f"Opgeslagen: output/netflix_titles_clean.csv ({len(df)} rijen)")

# Maandelijkse tijdreeks bouwen (basis voor de forecast)
ts_df = df.dropna(subset=["date_added"]).copy()
monthly_total = (
    ts_df.groupby(ts_df["date_added"].dt.to_period("M"))
    .size()
    .reset_index(name="titles_added")
)
monthly_total.columns = ["ds", "y"]
monthly_total["ds"] = monthly_total["ds"].dt.to_timestamp()
monthly_total.to_csv("output/netflix_monthly_total.csv", index=False)
print(f"Opgeslagen: output/netflix_monthly_total.csv ({len(monthly_total)} maanden)")

# ===========================================================
# STAP 5: Prophet forecast
# ===========================================================
from prophet import Prophet
import matplotlib.pyplot as plt

model = Prophet(
    yearly_seasonality=True,
    weekly_seasonality=False,
    daily_seasonality=False,
    interval_width=0.80,
)
model.fit(monthly_total)

FORECAST_MONTHS = 18
future = model.make_future_dataframe(periods=FORECAST_MONTHS, freq="MS")
forecast = model.predict(future)

result = forecast[["ds", "yhat", "yhat_lower", "yhat_upper"]].copy()
result.columns = ["date", "forecast", "forecast_lower", "forecast_upper"]
result = result.merge(monthly_total.rename(columns={"ds": "date", "y": "actual"}), on="date", how="left")
result.to_csv("output/netflix_forecast.csv", index=False)
print(f"\nOpgeslagen: output/netflix_forecast.csv ({len(result)} rijen, waarvan {FORECAST_MONTHS} maanden puur voorspelling)")

fig = model.plot(forecast)
plt.title("Netflix: voorspeld aantal nieuwe titels per maand")
plt.xlabel("Datum")
plt.ylabel("Aantal titels")
plt.tight_layout()
plt.savefig("output/netflix_forecast_plot.png", dpi=150)
plt.show()

last_actual = monthly_total["y"].iloc[-1]
last_actual_date = monthly_total["ds"].iloc[-1].date()
next_forecast = result[result["actual"].isna()].iloc[0]
print(f"\nLaatste bekende maand ({last_actual_date}): {last_actual} titels")
print(f"Voorspelling voor {next_forecast['date'].date()}: {next_forecast['forecast']:.0f} titels "
      f"(interval: {next_forecast['forecast_lower']:.0f} - {next_forecast['forecast_upper']:.0f})")

# ===========================================================
# STAP 6: Downloaden naar je laptop
# ===========================================================
files.download("output/netflix_titles_clean.csv")   # voor Power BI dashboard
files.download("output/netflix_forecast.csv")        # voor Power BI forecast-visual
files.download("output/netflix_forecast_plot.png")   # ter controle
